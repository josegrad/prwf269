﻿/* File Created: February 7, 2012 */

var bullet = function (x, y, health) {
	
    this.x = x;
    this.y = y;
	this.health = health;
    /*this.draw = function () { 

			var img=new Image();
			img.src=texture;
			ctx.drawImage("images/lazer.png",this.x,this.y);				
          
            this.y -= 7;
        }
    }*/
}

